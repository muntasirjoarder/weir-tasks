﻿using Azure.Storage.Queues;
using AzureQueueDemo.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AzureQueueDemo.Service
{
    public class QueueFactory
    {
        private readonly QueueConfiguration _config;
        public QueueFactory(QueueConfiguration config)
        {
            this._config = config;
        }

        public QueueClient CreateIfNotExists(string queueName)
        {
            if(_config.ConnectWith?.ToLower() == "sas" )
            {
                return CreateFromSAS(_config.SAS, queueName);
            }
                return CreateFromSharedKey(_config.ConnectionString, queueName);
        }

        private QueueClient CreateFromSharedKey(string connectionString, string queueName)
        {
            var queue = new QueueClient(connectionString,queueName);
            queue.CreateIfNotExists();
            return queue;
        }

        private QueueClient CreateFromSAS(string sas, string queueName)
        {
            var accountName = sas.Substring(sas.IndexOf("BlobEndpoint=https://") + "BlobEndpoint=https://".Length, sas.IndexOf("core.windows.net"));
            accountName = accountName.Split('.').FirstOrDefault();
            if (accountName == default) throw new ArgumentException("sas uri is not in the correct format");
            var signature = sas.Substring(sas.IndexOf("SharedAccessSignature=") + "SharedAccessSignature=".Length);
            // Construct the blob endpoint from the account name.
            string queueEndpoint = string.Format("https://{0}.queue.core.windows.net/{1}", accountName, queueName);
            var uri = new Uri(queueEndpoint);
            var queue = new QueueClient(uri, new Azure.AzureSasCredential(signature));
            queue.CreateIfNotExists();
            return queue;
        }
    }
}
