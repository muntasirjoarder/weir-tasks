﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AzureQueueDemo.Configuration
{
    public class QueueConfiguration
    {
        /// <summary>
        /// source queue "device-events"
        /// </summary>
        public string SourceQueue { get; set; }
        /// <summary>
        /// destination queue "device-measurements"
        /// </summary>
        public string DestinationQueue { get; set; }

        /// <summary>
        /// can be one of "SAS" or "ConnectionString", default is "ConnectionString"
        /// </summary>
        public string ConnectWith{ get; set; }
        
        /// <summary>
        /// Shared access signature  connection string
        /// </summary>
        public string SAS { get; set; }
        /// <summary>
        /// Shared ley azure Queue storage connection string
        /// </summary>
        public string ConnectionString { get; set; }
        /// <summary>
        /// threshold applied in business logic to update the messages in the destination queue
        /// </summary>
        public decimal ChangeThreshold { get; set; }
        /// <summary>
        /// Delay in seconds, represent time to wait till the next iteration after finishing processing the queue
        /// </summary>
        public int Delay { get; set; }
    }
}
