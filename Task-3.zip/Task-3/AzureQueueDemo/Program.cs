﻿using AzureQueueDemo.Configuration;
using AzureQueueDemo.Messages;
using AzureQueueDemo.Service;
using AzureQueueDemo.Startup;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Serilog;
using Serilog.Events;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;

namespace AzureQueueDemo
{
    class Program
    {
        public static IConfigurationRoot Configuration { get; set; }
        private static ServiceProvider _serviceProvider;
        public static ServiceProvider ServiceProvider
        {
            get
            {
                if (_serviceProvider != null)
                {
                    return _serviceProvider;
                }
                var serviceCollection = new ServiceCollection();
                ConfigureServices(serviceCollection);
                _serviceProvider = serviceCollection.BuildServiceProvider();
                return _serviceProvider;
            }
        }



        public static void Main(string[] args)
        {
            Configuration = new ConfigurationBuilder()
                .AddJsonFile("appsettings.json", false, true)
                .AddEnvironmentVariables()
                .Build();

            SetupLogger();

            if (!args.Any())
            {
                HandleInvalidStartupMode();
                return;
            }

            try
            {
                RunApplication(args);
            }
            catch (System.AggregateException ex)
            {
                if (ex.InnerException is TaskCanceledException)
                {

                    Log.Information("Canceled!");
                }
                else
                {
                    Log.Error(ex.ToString());
                }
            }
            catch (System.Exception ex)
            {
                Log.Fatal(ex.ToString());
            }
        }

        private static void ConfigureServices(ServiceCollection services)
        {
            var settings = new QueueConfiguration();
            Configuration.Bind(settings);
            services.AddSingleton(_ => settings);
            AppDomain.CurrentDomain.ProcessExit += (s, e) => Log.CloseAndFlush();
            // add logging
            services.AddSingleton(Log.Logger);
            services.AddSingleton<QueueFactory>();
            services.AddSingleton<ProcessorStartup>();
            services.AddSingleton<GeneratorStartup>();
        }


        private static void SetupLogger()
        {
            var directoryRoot = Directory.GetCurrentDirectory();
            var logPath = Path.Combine(directoryRoot, @"logs", "log-{Date}.log");
            Log.Logger = new LoggerConfiguration()
                .MinimumLevel.Debug()
                .WriteTo.Console()
                .WriteTo.RollingFile(logPath, LogEventLevel.Information)
                .CreateLogger();
        }

        private static void HandleInvalidStartupMode()
        {
            Log.Information("You need to add a param for the startup mode");
            Log.Information(@"Startup mode should be:");
            Log.Information(@"=> 'generate <message_count=10>' generate <message_count> fake messages for test, defaults to 10 messages ");
            Log.Information(@"=> 'process' : start processing queues ");
            Log.Information("Application will now exit");
            Console.Read();
        }

        private static void RunApplication(string[] args)
        {
            // a CancellationToken that is canceled when the user hits Ctrl+C.
            var cts = new CancellationTokenSource();
            Console.CancelKeyPress += (s, e) =>
            {
                Console.WriteLine("Canceling...");
                cts.Cancel();
                e.Cancel = true;
            };
            switch (args[0])
            {
                case "generate":
                    {
                        ServiceProvider.GetService<GeneratorStartup>().Run(args, cts.Token).Wait();
                        break;
                    }
                case "process":
                    {
                        ServiceProvider.GetService<ProcessorStartup>().Run(args, cts.Token).Wait();
                        break;
                    }
                default:
                    {
                        HandleInvalidStartupMode();
                        break;
                    }
            }
        }
    }

}