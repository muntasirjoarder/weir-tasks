﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace AzureQueueDemo.Messages
{
    public class DeviceEvent
    {
        public Guid MeasurementId { get; set; }
        public string SensorId { get; set; }
        public DateTime CreatedAt { get; set; }
        public decimal Value { get; set; }

        public override string ToString()
        {
            return JsonSerializer.Serialize(this);
        }
    }
}
