﻿using System.Threading;
using System;
using System.Linq;
using System.Collections.Generic;
using System.Text.Json;
using System.Threading.Tasks;
using AzureQueueDemo.Configuration;
using AzureQueueDemo.Messages;
using Serilog;
using Azure.Storage.Queues;
using Azure.Storage.Queues.Models;
using Azure.Identity;
using AzureQueueDemo.Service;

namespace AzureQueueDemo.Startup
{
    class ProcessorStartup : IStartup
    {
        private readonly ILogger _logger;
        private readonly QueueConfiguration _config;
        private readonly QueueFactory _factory;
        // TODO! consider using concurrent dictionnary
        private readonly Dictionary<string, DeviceEvent> _dictionnary = new Dictionary<string, DeviceEvent>();

        public ProcessorStartup(
            ILogger logger,
            QueueConfiguration config,
            QueueFactory factory)
        {

            _logger = logger;
            _config = config;
            _factory = factory;
        }

        public async Task Run(string[] args, CancellationToken cancellationToken)
        {

         
            var sourceQueue = _factory.CreateIfNotExists( _config.SourceQueue);
            var destinaitonQueue = _factory.CreateIfNotExists(_config.DestinationQueue);
            _logger.Information($"Reading message from {_config.SourceQueue} queue");

            while (!cancellationToken.IsCancellationRequested)
            {
                var messages = await sourceQueue
                .ReceiveMessagesAsync(maxMessages: 32, cancellationToken: cancellationToken); // max is 32 per http call
                foreach (var message in messages.Value)
                {
                    if(message.DequeueCount>1)
                    {
                        _logger.Information("Message {0}  has already been dequeued and processed before {1}, skiping ", message.MessageText, message.DequeueCount);
                        continue;
                    }
                    var @event = DeserializeMessage(message);
                    if (@event is null)
                    {
                        continue;
                    }
                    var alreadyAdded = false;
                    if (@event.Value < 1 || @event.Value > 9)
                    {
                        _logger.Information("Adding message to {0} (value<1 or value >9): message= {1} ", _config.DestinationQueue, @event);
                        await destinaitonQueue.SendMessageAsync(@event.ToString(), cancellationToken: cancellationToken);
                        // uncomment to deleted processed messages from the queue
                        //_logger.Information("Deleting message from {0}: message= {1} ", _config.SourceQueue, @event);
                        //await sourceQueue.DeleteMessageAsync(message.MessageId, message.PopReceipt, cancellationToken: cancellationToken);
                        alreadyAdded = true;
                    }
                    if (_dictionnary.TryGetValue(@event.SensorId, out var lastEvent))
                    {
                        var changePercentage = Math.Abs(100 * (lastEvent.Value - @event.Value) / lastEvent.Value);
                        if (changePercentage > _config.ChangeThreshold)
                        {
                            _dictionnary[@event.SensorId] = @event;
                            if (!alreadyAdded)
                            {
                                _logger.Information("Adding message to {0} (value changed by {1}%): message= {2} ",
                                 _config.DestinationQueue, Math.Round(changePercentage, 2), @event);
                                await destinaitonQueue.SendMessageAsync(@event.ToString(), cancellationToken: cancellationToken);
                                // uncomment to deleted processed messages from the queue
                                //_logger.Information("Deleting message from {0}: message= {1} ", _config.SourceQueue, @event);
                                //await sourceQueue.DeleteMessageAsync(message.MessageId, message.PopReceipt, cancellationToken: cancellationToken);
                            }
                        }
                    }
                    else
                    {
                        _dictionnary.Add(@event.SensorId, @event);
                    }
                }
                _logger.Information("Delaying for {0} seconds before the next processing iteration ", _config.Delay);
                await Task.Delay(TimeSpan.FromSeconds(_config.Delay), cancellationToken);
            }
        }

        private DeviceEvent DeserializeMessage(QueueMessage message)
        {
            try
            {
                return JsonSerializer.Deserialize<DeviceEvent>(message.MessageText);
            }
            catch (System.Exception ex)
            {
                _logger.Fatal("Failed to deserialize message ", ex.ToString());
                return null;
            }
        }
    }
}
