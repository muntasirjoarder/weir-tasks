﻿using System;
using System.Collections.Generic;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;
using Azure.Storage.Queues;
using AzureQueueDemo.Configuration;
using AzureQueueDemo.Messages;
using AzureQueueDemo.Service;
using Serilog;

namespace AzureQueueDemo.Startup
{
    class GeneratorStartup : IStartup
    {
        private readonly string SENSOR_PREFIX = "sens00";
        private const int DEFAULT_MESSAGE_COUNT = 10;
        private readonly ILogger _logger;
        private readonly QueueFactory _factory;
        private readonly QueueConfiguration _config;

        // private readonly IQueueManager _queueManager;
        public GeneratorStartup(
            ILogger logger,
            QueueConfiguration config, 
            QueueFactory factory)
        {

            _logger = logger;
            _config = config;
            _factory = factory;
        }

        public async Task Run(string[] args, CancellationToken cancellationToken)
        {
            // await _queueManager.Test(_config.SourceQueue);
            // return;
            if (args.Length < 2 || !int.TryParse(args[1], out var messageCount))
            {
                messageCount = DEFAULT_MESSAGE_COUNT;

            }

            // ensure queues are created
            var sourceQueue = _factory.CreateIfNotExists(_config.SourceQueue);
            var destinationQueue = _factory.CreateIfNotExists(_config.DestinationQueue);
            _logger.Information($"Creating {_config.SourceQueue} queue");
            await sourceQueue.CreateIfNotExistsAsync(cancellationToken: cancellationToken);
            _logger.Information($"Creating {_config.DestinationQueue} queue");
            await destinationQueue.CreateIfNotExistsAsync(cancellationToken: cancellationToken);

            var messages = GenerateDummyMessages(messageCount);
            _logger.Information($"Generating {messageCount} messages");
            foreach (var message in messages)
            {
                if (cancellationToken.IsCancellationRequested) break;
                _logger.Information("Message enqueued {0} ", message.ToString());
                await sourceQueue.SendMessageAsync(message.ToString(), cancellationToken: cancellationToken);
            }

        }
        ///<summary>
        ///generate fake messages
        ///<summary>

        private IEnumerable<DeviceEvent> GenerateDummyMessages(int count)
        {
            var random = new Random(20);
            for (int i = 0; i < count; i++)
            {
                yield return new DeviceEvent
                {
                    MeasurementId = Guid.NewGuid(),
                    SensorId = SENSOR_PREFIX + random.Next(0, 10),
                    Value = (decimal)Math.Round(random.Next(0, 20) + random.NextDouble(), 3),
                    CreatedAt = DateTime.UtcNow,
                };

            }
        }
    }

}
